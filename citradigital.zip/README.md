# Document Scanner

Project UAS Pengolahan Citra Digital, Universitas Pamulang.

Aplikasi mengubah foto kertas yang miring atau berlatar berantakan menjadi hasil scan
hitam-putih yang lurus dan rapi, seperti aplikasi CamScanner.

## Teknik pengolahan citra yang dipakai

| Tahap | Teknik | Fungsi OpenCV |
|---|---|---|
| 1 | Grayscale | `cvtColor` |
| 2 | Gaussian blur | `GaussianBlur` |
| 3 | Canny edge detection | `Canny` |
| 4 | Morfologi closing | `morphologyEx` |
| 5 | Contour + approxPolyDP | `findContours`, `approxPolyDP` |
| 6 | Perspective transform | `getPerspectiveTransform`, `warpPerspective` |
| 7 | Adaptive threshold | `adaptiveThreshold` |

Alur: gambar -> grayscale -> blur -> Canny -> closing -> contour 4 sudut ->
perspective transform -> adaptive threshold -> hasil scan.

## Instalasi

Butuh Python 3.9 atau lebih baru.

```bash
pip install -r requirements.txt
```

Opsional memakai virtual environment:

```bash
python -m venv venv
# Linux/Mac:   source venv/bin/activate
# Windows:     venv\Scripts\activate
pip install -r requirements.txt
```

## Cara menjalankan

Cara termudah: jalankan tanpa argumen, lalu pilih dari menu.

```bash
python src/main.py
```

Gambar boleh dari folder `images/` atau dari lokasi mana saja (ketik atau drag-drop path file).

Atau lewat perintah langsung:

```bash
# Buat 3 gambar uji demo (opsional, kalau belum punya foto sendiri)
python make_samples.py

# Scan satu atau banyak gambar
python src/main.py --image images/uji1_meja_kayu.jpg

# Mode webcam: tekan S untuk simpan, Q untuk keluar
python src/main.py --webcam
```

Hasil tiap tahap tersimpan di folder `hasil/` dengan akhiran `_gray`, `_blur`, `_edges`,
`_closed`, `_outline`, `_warped`, dan `_scanned`.

## Parameter yang bisa diubah (untuk tanya jawab dosen)

| Parameter | File | Dampak bila diubah |
|---|---|---|
| `BLUR_KERNEL` | preprocessing.py | Kernel besar: noise hilang tapi tepi kertas ikut kabur |
| `CANNY_LOW`, `CANNY_HIGH` | preprocessing.py | Rendah: banyak tepi palsu. Tinggi: tepi kertas bisa hilang |
| `MORPH_KERNEL` | preprocessing.py | Besar: garis putus tersambung, tapi objek lain bisa ikut menyatu |
| `MIN_AREA_RATIO` | detection.py | Batas luas minimum kontur yang dianggap dokumen |
| `21, 10` di adaptiveThreshold | detection.py | Ukuran blok dan konstanta. Konstanta kecil: lebih banyak bintik noise |

## Keterbatasan

- Gagal bila warna kertas hampir sama dengan latar (tepi tidak terdeteksi).
- Gagal bila sebagian sudut kertas tertutup atau keluar frame.
- Hanya mendeteksi dokumen berbentuk 4 sudut.
- Pada pencahayaan sangat tidak rata atau gambar ber-noise, hasil threshold bisa berbintik.

## Pengungkapan (sesuai ketentuan UAS)

- Library: OpenCV dan NumPy.
- Pendekatan pipeline document scanner (contour 4 titik + perspective transform) adalah
  teknik umum yang banyak dibahas di tutorial OpenCV.
- Bantuan AI: kode awal dibuat dengan bantuan Claude (Anthropic).
  Ubah bagian ini dengan keterangan yang sesuai, dan pastikan kamu paham semua kodenya.
