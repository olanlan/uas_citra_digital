"""Mode manual: pengguna mengklik sendiri 4 sudut dokumen.

Dipakai bila deteksi otomatis gagal, misalnya halaman buku putih di atas
meja terang yang tepinya hampir tidak terlihat.
"""
import cv2
import numpy as np

DISPLAY_HEIGHT = 800  # tinggi jendela agar muat di layar laptop
WINDOW_NAME = "Pilih 4 sudut dokumen"
KEY_ENTER = 13
KEY_ESC = 27


class CornerPicker:
    """Menyimpan klik mouse dan menggambar petunjuknya di gambar."""

    def __init__(self, image, display_height=DISPLAY_HEIGHT):
        height = image.shape[0]
        # Gambar hanya diperkecil, tidak pernah diperbesar
        self.scale = min(1.0, display_height / float(height))
        self.display = cv2.resize(image, None, fx=self.scale, fy=self.scale)
        self.points = []

    def on_mouse(self, event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN and len(self.points) < 4:
            self.points.append((x, y))

    def reset(self):
        self.points = []

    def is_complete(self):
        return len(self.points) == 4

    def render(self):
        """Gambar titik, garis penghubung, dan teks petunjuk."""
        canvas = self.display.copy()
        for index, point in enumerate(self.points):
            cv2.circle(canvas, point, 6, (0, 0, 255), -1)
            cv2.putText(canvas, str(index + 1), (point[0] + 8, point[1] - 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        if len(self.points) > 1:
            lines = np.array(self.points, dtype=np.int32).reshape(-1, 1, 2)
            cv2.polylines(canvas, [lines], self.is_complete(), (0, 255, 0), 2)

        if self.is_complete():
            hint = "Enter = proses | R = ulang | Esc = batal"
        else:
            hint = f"Klik sudut {len(self.points) + 1} dari 4 | R = ulang | Esc = batal"
        cv2.rectangle(canvas, (0, 0), (canvas.shape[1], 30), (0, 0, 0), -1)
        cv2.putText(canvas, hint, (10, 21), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (255, 255, 255), 1)
        return canvas

    def original_points(self):
        """Kembalikan titik ke koordinat gambar asli (4 baris x,y)."""
        return np.array(self.points, dtype="float32") / self.scale


def select_corners(image):
    """Tampilkan gambar, tunggu pengguna memilih 4 sudut.

    Mengembalikan array 4 titik pada gambar asli, atau None bila dibatalkan.
    Urutan klik bebas, karena nanti diurutkan otomatis.
    """
    picker = CornerPicker(image)
    cv2.namedWindow(WINDOW_NAME)
    cv2.setMouseCallback(WINDOW_NAME, picker.on_mouse)

    result = None
    while True:
        cv2.imshow(WINDOW_NAME, picker.render())
        key = cv2.waitKey(20) & 0xFF

        if key == KEY_ESC:
            break
        if key in (ord("r"), ord("R")):
            picker.reset()
        if key == KEY_ENTER and picker.is_complete():
            result = picker.original_points()
            break
        # Jendela ditutup dengan tombol X
        if cv2.getWindowProperty(WINDOW_NAME, cv2.WND_PROP_VISIBLE) < 1:
            break

    cv2.destroyAllWindows()
    return result
